package pl.paulb.character.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.paulb.character.dto.PersonaDTO;
import pl.paulb.character.service.PersonaService;

import java.util.List;

@RestController
@RequestMapping("/api/characters")
public class PersonaController {

    @Autowired
    private PersonaService personaService;

    @PostMapping
    public ResponseEntity<PersonaDTO> createGameCharacter(@Valid @RequestBody PersonaDTO PersonaDTO) {
        return ResponseEntity.ok(personaService.createGameCharacter(PersonaDTO));
    }

    @GetMapping
    public List<PersonaDTO> getAllCharacters() {
        return personaService.getAllGameCharacters();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PersonaDTO> getGameCharacterById(@PathVariable Long id) {
        return personaService.getGameCharacterById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<PersonaDTO> updateGameCharacter(@PathVariable Long id, @Valid @RequestBody PersonaDTO personaDTO) {
        return ResponseEntity.ok(personaService.updateGameCharacter(id, personaDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGameCharacter(@PathVariable Long id) {
        personaService.deleteGameCharacter(id);
        return ResponseEntity.noContent().build();
    }
}
