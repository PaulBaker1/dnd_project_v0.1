package pl.paulb.character.model;

public enum ClassType {
    WARRIOR,
    MAGE,
    ROGUE,
    CLERIC,
    BARD,
    RANGER
}
