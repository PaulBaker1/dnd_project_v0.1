package pl.paulb.character.service;

import org.springframework.stereotype.Service;
import pl.paulb.character.dto.PersonaDTO;
import pl.paulb.character.model.Persona;
import pl.paulb.character.repository.PersonaRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PersonaService {

    private final PersonaRepository personaRepository;

    // Constructor injection for the repository
    public PersonaService(PersonaRepository personaRepository) {
        this.personaRepository = personaRepository;
    }

    /**
     * Creates a new GameCharacter based on the provided DTO and saves it to the repository.
     *
     * @param personaDTO The GameCharacterDTO containing character information.
     * @return The saved GameCharacter as a DTO.
     */
    public PersonaDTO createGameCharacter(PersonaDTO personaDTO) {
        Persona persona = convertToEntity(personaDTO);
        Persona savedCharacter = personaRepository.save(persona);
        return convertToDTO(savedCharacter);
    }

    /**
     * Retrieves all GameCharacters from the repository and converts them to DTOs.
     *
     * @return A list of GameCharacterDTOs.
     */
    public List<PersonaDTO> getAllGameCharacters() {
        return personaRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Retrieves a GameCharacter by ID and converts it to a DTO.
     *
     * @param id The ID of the GameCharacter.
     * @return An Optional containing the GameCharacterDTO if found, or empty if not found.
     */
    public Optional<PersonaDTO> getGameCharacterById(Long id) {
        return personaRepository.findById(id)
                .map(this::convertToDTO);
    }

    /**
     * Updates an existing GameCharacter identified by ID with new data from the provided DTO.
     *
     * @param id The ID of the GameCharacter to update.
     * @param personaDTO The new data for the GameCharacter.
     * @return The updated GameCharacter as a DTO.
     */
    public PersonaDTO updateGameCharacter(Long id, PersonaDTO personaDTO) {
        Persona existingCharacter = personaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("GameCharacter not found"));

        updateEntityFromDTO(existingCharacter, personaDTO);
        Persona updatedCharacter = personaRepository.save(existingCharacter);
        return convertToDTO(updatedCharacter);
    }

    /**
     * Deletes a GameCharacter by ID.
     *
     * @param id The ID of the GameCharacter to delete.
     */
    public void deleteGameCharacter(Long id) {
        if (!personaRepository.existsById(id)) {
            throw new RuntimeException("GameCharacter not found");
        }
        personaRepository.deleteById(id);
    }

    // Conversion method to transform GameCharacter entity to GameCharacterDTO
    private PersonaDTO convertToDTO(Persona character) {
        return PersonaDTO.builder()
                .id(character.getId())
                .name(character.getName())
                .race(character.getRace())
                .classType(character.getClassType())
                .level(character.getLevel())
                .strength(character.getStrength())
                .dexterity(character.getDexterity())
                .constitution(character.getConstitution())
                .intelligence(character.getIntelligence())
                .wisdom(character.getWisdom())
                .charisma(character.getCharisma())
                .build();
    }

    // Conversion method to transform GameCharacterDTO to GameCharacter entity
    private Persona convertToEntity(PersonaDTO dto) {
        return Persona.builder()
                .name(dto.getName())
                .race(dto.getRace())
                .classType(dto.getClassType())
                .level(dto.getLevel())
                .strength(dto.getStrength())
                .dexterity(dto.getDexterity())
                .constitution(dto.getConstitution())
                .intelligence(dto.getIntelligence())
                .wisdom(dto.getWisdom())
                .charisma(dto.getCharisma())
                .build();
    }

    // Method to update an existing GameCharacter entity from a GameCharacterDTO
    private void updateEntityFromDTO(Persona character, PersonaDTO dto) {
        character.setName(dto.getName());
        character.setRace(dto.getRace());
        character.setClassType(dto.getClassType());
        character.setLevel(dto.getLevel());
        character.setStrength(dto.getStrength());
        character.setDexterity(dto.getDexterity());
        character.setConstitution(dto.getConstitution());
        character.setIntelligence(dto.getIntelligence());
        character.setWisdom(dto.getWisdom());
        character.setCharisma(dto.getCharisma());
    }
}