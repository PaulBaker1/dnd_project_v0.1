package pl.paulb.character.model;

public enum RaceType {
    HUMAN,
    DWARF,
    ELF,
    GNOME,
    ORC
}

